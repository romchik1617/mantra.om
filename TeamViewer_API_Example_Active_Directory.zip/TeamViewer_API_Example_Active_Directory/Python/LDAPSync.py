#####################################################
# Purpose: Sync company member with an ActiveDirectory/LDAP Group.
# 
# Copyright (c) 2014 TeamViewer GmbH
# Example created 2014-02-20
# Version 1.1
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
# When reusing or redistributing the software please respect any licenses of
# included software from third parties, if applicable.
#####################################################


# -requires python-ldap (see http://www.python-ldap.org/)
###############

###############
# Configuration
###############

# API access token
accessToken = "XX-XXXXXXXXXXXXXXXXXXXX" #<-- your access token, can be left empty when OAuth (below) is configured.

# OAuth: API client id & authorizationCode
# if all variables are set here, OAuth will be used to request an access token
clientId = ""               #<-- Create an app in your TeamViewer Management Console and insert the client ID here.
clientSecret = ""			#<-- Insert your client secret here.
authorizationCode = ""      #<-- Visit https://webapi.teamviewer.com/api/v1/oauth2/authorize?response_type=code&client_id=YOURCLIENTIDHERE
                            #    Login, grant the permissions (popup) and put the code shown in the authorizationCode variable here

# domain settings
dn = "dc=testad,dc=local"

# user with ldap read permission
ldapUser = "myuser"
ldapUserPw = "mypw"

# ldap settings
dcIP = "127.0.0.1"
dcLdapPort = "389"

# user group to sync with management console
syncGroupCN = "tvuser"
syncGroupOU = "myUsers"
syncGroupSearchFilter = "(&(objectCategory=user)(memberOf=cn=" + syncGroupCN + ",ou=" + syncGroupOU +  "," + dn + "))"

# new user defaults (if not available in csv import file)
defaultUserLanguage = "en"
defaultUserPassword = "myInitalPassword!"
defaultUserPermissions = "ShareOwnGroups,EditConnections,EditFullProfile,ViewOwnConnections"

# deactivate company users not found in the configured AD group 
deactivateUnknownUsers = False
# testRun needs to be set to false for the script to perform actual changes
testRun = True

##########
# includes
##########

import os, csv
import Common
import ldap # requires python-ldap(http://www.python-ldap.org/)

###########
# Functions
###########

# Returns the AD members of the configured usergroup from above
def GetADMembersOfOU():

    ldap.set_option(ldap.OPT_REFERRALS, 0)
    ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
    ldapClient = ldap.initialize('ldap://' + dcIP + ":" + dcLdapPort)
    ldapClient.simple_bind_s(ldapUser, ldapUserPw)
    
    count = 0
    result_set = []
    timeout = 0
    retrieve_attributes = ["name", "mail", "givenName", "sn", "department", "description", "userAccountControl"] # None -> requesting all attributes
    result = {}

    try:
        result_id = ldapClient.search(dn, ldap.SCOPE_SUBTREE, syncGroupSearchFilter,retrieve_attributes)

        while 1:
                result_type, result_data = ldapClient.result(result_id, timeout)
                if (result_data == []):
                    break
                else:
                    if result_type == ldap.RES_SEARCH_ENTRY:
                        result_set.append(result_data)

        if len(result_set) == 0:
            print "No Results."

        for i in range(len(result_set)):
            for entry in result_set[i]:                 
                try:
                    user = {}
                    user["email"] = entry[1]['mail'][0]
                    user["name"] = entry[1]['givenName'][0] + " " + entry[1]['sn'][0]

                    #MS specific: Check if user is deactivated
                    userFlags = int(entry[1]["userAccountControl"][0])
                    if (userFlags & 0x2 == 0x2):
                        print "User is disabled. Skipped."
                    else:
                        result[user["email"]] = user                        
                    
                except:
                    print "AD user is missing name and/or email. Skipped."
                    pass

    except ldap.LDAPError, error_message:
        print error_message

    ldapClient.unbind_s()
    return result

#######################################
# Sync AD Usergroup with TeamViewer Api
#######################################

if (testRun == True):
    infoStr = "testRun is set to true. Information in your TeamViewer account will not be modified. Instead, all changes that would be made are displayed on the console. Press ENTER to continue..."
    raw_input(infoStr)

print "Starting AD OU Sync..."

# check OAuth requirements
if (len(clientId) > 0 and len(authorizationCode) > 0):
    token = Common.RequestOAuthAccessToken(clientId, clientSecret, authorizationCode)
    if(token and len(token) > 0):
        accessToken = token

#ping API to check connection and token
if (Common.PingAPI(accessToken)):
    
    #read users from the AD OU
    dictUsersAD = GetADMembersOfOU()

    #get all current users of our company from the API
    arrUsersAPI = Common.GetAllUsersAPI(accessToken)

    #put all current API users in a dictionary, id field as key
    dictUsersAPI = {}
    for u in arrUsersAPI:
        print u["id"]
        dictUsersAPI[u["id"]] = u

    #sync
    #for each user in AD group: check against API if user exists (by mail)	
    for usrKey in dictUsersAD:	
    #Write-Host $usrKey

        userApi = None
        userAD = None

        userAD = dictUsersAD[usrKey]
        userApi = Common.GetUserByMail(accessToken, usrKey) #lookup API user by mail	

        if(userApi): #user found -> update user
            print "User with email=" +  usrKey + " found."

            if (testRun == True):
                print "UpdateUser: " + usrKey + " with this values:"
                for key, value in userAD.iteritems():
                    print key + " = " + value
                del dictUsersAPI[userApi[0]["id"]]
            else:
                #Update the user
                Common.UpdateUser(accessToken, userApi[0]["id"], userAD)
                #remove this user from our dictionary
                del dictUsersAPI[userApi[0]["id"]]

        else: #no user found -> create user		
            print "No user with email=" + usrKey + " found."
            if (testRun == True):
                print "CreateUser: " + usrKey + " with this values:"
                for key, value in userAD.iteritems():
                    print key + " = " + value
            else:
                #Create User
                Common.CreateUser(accessToken, userAD, defaultUserPermissions, defaultUserLanguage, defaultUserPassword)

    # if configured, deactivate all users not in AD group
    if (deactivateUnknownUsers == True):
        
        if (testRun == True):
            print "Deactivate Unknown Users:"
            for value in dictUsersAPI.itervalues():
                print "Deactivate User: id = " + value["id"] + " name = " + value["name"]
        else:
            #all users remaining in dictUsersAPI dictionary are not present in the AD group an can be deactivated
            for id in dictUsersAPI:		
                Common.DeactivateUser(accessToken, id)    

else:
	print "No data imported. Token or connection problem."

print ("AD OU Sync finished.")