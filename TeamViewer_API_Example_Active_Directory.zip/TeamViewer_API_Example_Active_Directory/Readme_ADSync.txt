Readme for TeamViewer API example scripts: AD/LDAP Sync v1.1
This script is provided for the following languages: PowerShell 2, Python 2.x.

The ADSync/LDAPSync Script synchronizes your Active Directory users with the TeamViewer Management Console. 
You can only synchronize one group at once.

Configuration:

# Test run
If the variable testRun is set to true, the script will perform a test run. That way, no actual changes are made to the TeamViewer users. Instead, a console output displays what changes would be made. testRun is set to true by default.

# Access Settings
In order for this script to access your data, you mus either set the -accessToken- or all of the values required for OAuth 2.0: -clientId-, -clientSecret- and -authorizationCode-.

	-accessToken-
	Stores your script token. For information on how to create your own script token, please visit: http://integrate.teamviewer.com/en/develop/getStarted/#createScript 

	-clientId-
	Create an app in your TeamViewer Management Console and insert the client ID here.
	For further information please visit: http://integrate.teamviewer.com/en/develop/getStarted/#createApplication 

	-clientSecret-
	Insert your client secret here.

	-authorizationCode-
	With your client ID, visit https://webapi.teamviewer.com/api/v1/oauth2/authorize?response_type=code&client_id=YOURCLIENTIDHERE
	Login, grant the permissions (popup) and insert the code shown in the authorizationCode variable here.

# Domain Settings

	-dn-
	Contains the domain components to the starting point of your query. For Example if the query should start at "users.example.com" 
	the input would be "dc=users,dc=example,dc=com"

# LDAP Credentials (Python only)

	-ldapUser-
	Defines the username for a user with LDAP read permission.

	-ldapUserPw-
	Defines the password for a user with LDAP read permission.

# Connection Settings

	-dcIP-
	Insert the IP address of the Active Directory Server here.

	-dcLdapPort-
	Insert the port of the Active Directory Server here.

# User Group Settings

	-syncGroupCN-
	Defines the Common Name of the user group.

	-syncGroupOU-
	Defines the Organizational Unit of the domain.

	-syncGroupSearchFilter-
	Defines the search filter using the values of dn, syncGroupCN and syncGroupOU. 

# New User Settings

	-defaultUserLanguage-
	Defines the language for new users. For example "en" for English or "de" for German.

	-defaultUserPassword-
	Defines the initial password for new users.

	-defaultUserPermissions-
	Defines the permissions for new users as a comma-separated list.
	For a list of all possible values refer to the API specification: http://integrate.teamviewer.com/en/develop/documentation/ 

	-deactivateUnknownUsers-
	In case a user is found in TeamViewer Management Console but not in the Active Directory, the script deactivates this user if this flag is set to true.

	
# Requirements for Python LDAP integration

In order to use the Python script with your Active Directory you need Python 2.x and the Python LDAP extension. 
We strongly recommend the 32-bit version (x86) of Python (see reason below)
You can download the LDAP extension at http://www.python-ldap.org. 


# Python x64

There is no official 64-bit version (x64) of the Python LDAP extension. 
If you need to use the x64 version of Python 2.x for some reason you can get an unofficial LDAP extension in 64 bit at 
http://www.lfd.uci.edu/~gohlke/pythonlibs/#python-ldap
